import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {LayoutComponent} from './layout/layout.component';
import {ClientesComponent} from './usuarios/clientes/clientes.component';
import {AdminComponent} from './usuarios/admin/admin.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/admin',
    pathMatch: 'full'
  },

  {
    path: '',
    component: LayoutComponent,
    children: [

      {
        path: 'clientes',
        component: ClientesComponent
      },
      {
        path: 'admin',
        component: AdminComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
