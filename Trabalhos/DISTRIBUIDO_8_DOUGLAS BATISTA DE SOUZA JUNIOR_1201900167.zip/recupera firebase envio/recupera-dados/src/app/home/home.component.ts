import { Component, OnInit } from '@angular/core';
import { LoginServicesService } from '../services/login-services.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(
    public auth: LoginServicesService,
  ) { }

  ngOnInit(): void {
  }

}
