import { NgModule } from '@angular/core';
import { AngularFireModule } from '@angular/fire';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AngularFireModule.initializeApp({
      apiKey: "AIzaSyCkWAAOVen9knmYvyA5rpHYkHfrP8oQePk",
    authDomain: "recuperar-dados-7be4b.firebaseapp.com",
    projectId: "recuperar-dados-7be4b",
    storageBucket: "recuperar-dados-7be4b.appspot.com",
    messagingSenderId: "711663171664",
    appId: "1:711663171664:web:bdf64baed8179e58bf7955"
    })

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
